// /// <reference types="cypress" />

// const { HOME_VARIABLES } = require("../../support/home_mapping_var")
// import {signIn,addPost,deletePost,likePost,addComment,addLink, reblog} from '../../support/home_func'
// import { WEB_URL } from '../../url'

// describe("Test Home",function(){
//     //sign into tumblr
//     it("sign in",function(){
        
//         signIn(HOME_VARIABLES.password,HOME_VARIABLES.email,WEB_URL)
       
//     })

//     //create post
//     it("create post",function(){
    
//         addPost("creating by a test script","post3")
        
//     })

//     // add like to a post
//     it("like post",function(){

//         likePost()
        
//     })
//     // add Comment to a post
//     it("comment post",function(){

//     addComment("This comment is created via automated test script")

//     })
//     //delete post
//     it("delete post",function(){

//         deletePost("post3")
        
//     })

//     // reblog
//      it("reblog post ",function(){

//         reblog()
        
//     })
//     // add link 
//     it("Add Link",function(){

//         addLink("cypress","https://docs.cypress.io/api/commands/route#Without-Stubbing")
        
//     })


    
// })
