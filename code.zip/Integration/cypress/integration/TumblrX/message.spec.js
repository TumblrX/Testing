// /// <reference types="cypress" />

// import { sendMsgForFriend, sendMsgForNewFriend, tsetSoundSettingRoute, tsetDeleteConversation } from'../../support/message_func'
// import { WEB_URL } from '../../url'
// describe('Message', () => {
//   beforeEach(() => {
//     cy.visit(WEB_URL) 
//     cy.visit('http://tumblrx.me:4000/') //http://tumblrx.me:4000/dashboard
//     cy.workingLogIn()
//   })

//   it("send a message to frind", function () {
//     sendMsgForFriend("hello from web")
//   })
//   it("send a message to new frind", function () {
//     sendMsgForNewFriend("Menna57", "hello from web")
//   })
//   it("sound settings route", function () {
//     tsetSoundSettingRoute()
//   })
//   it("delete conversation", function () {
//     tsetDeleteConversation()
//   }) 
// })
