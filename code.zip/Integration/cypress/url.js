 /** @const */const WEB_URL = 'http://front:4000' //tumblrx.me
module.exports = { WEB_URL }
