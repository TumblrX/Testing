 /** 
 * first div that contain two buttons, second sign up botton
 * @const BEGIN_LOG_IN */
  const BEGIN_LOG_IN = '.MainPage_login__27tt_'
/** 
 * main div to accesse the google button
 * @const CONTINUE_WITH_GOOGLE_BUTTON */
const CONTINUE_WITH_GOOGLE_BUTTON_MAIN = '.MainPage_container__3VWBn'
/** 
 * main div to accesse the google button
 * @const CONTINUE_WITH_GOOGLE_BUTTON */
const CONTINUE_WITH_GOOGLE_BUTTON_LOG_IN = '.LoginPage_container__28w_X'
/** 
* main div to accesse the google button
* @const CONTINUE_WITH_GOOGLE_BUTTON */
const CONTINUE_WITH_GOOGLE_BUTTON_SGIN_UP = '.Register_container__1jxC5'
/** 
 * my google email
 * @const MY_EMAIL  */
const MY_EMAIL = '.tgnCOd .WBW9sf'
/** @const */const VARIABLES = {
    CONTINUE_WITH_GOOGLE_BUTTON_MAIN: CONTINUE_WITH_GOOGLE_BUTTON_MAIN,
    CONTINUE_WITH_GOOGLE_BUTTON_LOG_IN: CONTINUE_WITH_GOOGLE_BUTTON_LOG_IN,
    CONTINUE_WITH_GOOGLE_BUTTON_SGIN_UP: CONTINUE_WITH_GOOGLE_BUTTON_SGIN_UP,
    MY_EMAIL: MY_EMAIL, BEGIN_LOG_IN: BEGIN_LOG_IN
}
module.exports = { VARIABLES }
