/// <reference types="cypress" />

import { LOG_IN } from'../../support/sgin_with_google_func'

describe('Message', () => {
//   beforeEach(() => {
//     cy.visit('http://tumblrx.me:4000/') //http://tumblrx.me:4000/dashboard
//   })
  it("is there placeholder", function () {
    LOG_IN()
  })
 
 
})
