/** 
 * first div that contain two buttons, second sign up botton
 * @const BEGIN_LOG_IN */
 const BEGIN_LOG_IN = '.Fygd5 .Z8Ux2'
 /** 
  * inside input tag in sign up form
  * @const INPUT_EMAIL  */
 const INPUT_EMAIL = 'input[name="email"]'
 /** 
  * inside input tag in sign up form
  * @const INPUT_PASSWORD */
 const INPUT_PASSWORD = 'input[name="password"]'
 /**
  * first div that contain form, second button
  *  @const LOG_IN_ACTION */
 const LOG_IN_ACTION = '.TRX6J .EvhBA'
 /** 
  * first div that contain form, second div contain error message
  * @const ERROR_MSG_FIRST */
 const ERROR_MSG_FIRST = '.Fygd5 .oFCPF'

 /** @const */const VARIABLES = {
     BEGIN_LOG_IN: BEGIN_LOG_IN, INPUT_EMAIL: INPUT_EMAIL, INPUT_PASSWORD: INPUT_PASSWORD, 
     LOG_IN_ACTION: LOG_IN_ACTION, ERROR_MSG_FIRST: ERROR_MSG_FIRST
    }
 module.exports = { VARIABLES }
 