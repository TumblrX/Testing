
/** @const */const ACCOUNT_ICON = '#root > #base-container > .D5eCV > .hlDot > ._3kR_ > .uuWZ2 > .KTRcB:nth-child(6)'
/** @const */const POSTS_PAGE = ACCOUNT_ICON + '> .BPf9u > .ybmTG > .AzqQv > .PsDsm > .noQqZ:nth-child(4) > div:nth-child(1) > .ZRl0t:nth-child(1) > .Z8ENW > .kbIQf > li:nth-child(1) > a:nth-child(1)'
/** @const */const POSTS_BLOCK = '#root > #base-container > .D5eCV > .gPQR5 > .lSyOz > .f5mVe > .j8ha0 > div:nth-child(2)'
/** @const */const POST_ID = "668359789741588480"
/** @const */const DELETE_ICON =' .ge_yK > .c79Av > article:nth-child(3) > div:nth-child(4) > footer > div:nth-child(2) > div:nth-child(5)'
/** @const */const CONFIRM_DELETE = '#root > #base-container > #glass-container > .Lq1wm > .RgTaQ > .Qluee > button:nth-child(2)'

var password = '211257mennamenna'
var email ='mennaahmedali77@gmail.com'

/** @const */const POST_VARIABLES = {

    POSTS_PAGE:POSTS_PAGE,
    ACCOUNT_ICON:ACCOUNT_ICON,
    POSTS_BLOCK:POSTS_BLOCK,
    POST_ID:POST_ID,
    DELETE_ICON:DELETE_ICON,
    CONFIRM_DELETE:CONFIRM_DELETE,
    password:password,
    email:email
}
module.exports={POST_VARIABLES}