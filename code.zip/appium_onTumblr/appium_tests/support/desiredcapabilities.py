desiredcap = {
  "platformName": "Android",
  "appium:platformVersion": "10.0",
  "appium:deviceName": "Nada",
  "appium:automationName": "Appium",
  # "appium:appPackage": "com.example.android.tumblrx2",
  # "appium:appActivity": "com.example.android.tumblrx2.intro.IntroActivity"
}