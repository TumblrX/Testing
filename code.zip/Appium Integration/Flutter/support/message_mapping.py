BAR_XPATH = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]"
HOME_MESSAGE_ICON_ACCESSE_ID = "Notifications Tab 3 of 4"
A_FRIEND_ACCESSE_ID= "example example: vmbnmvb Yesterday, 23:57" 
SEND_BUTTON_XPATH= "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.Button"

SAY_SOMETHING_XPATH = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText"
NEW_MESSAGE_BUTTON_XPATH = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.view.View/android.view.View/android.view.View[4]/android.view.View/android.view.View/android.widget.Button"
SEARCH_FOR_NEW_FRIND_XPATH = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.EditText"
# MY_NEW_FRIEND_ACCESSE_ID = it has access id = frind name
# LAST_MESSAGE_ID = it has access id = message it self
BACK_BUTTON_ACCESSE_ID = "Back"
MORE_OPTIONS_ACCESSE_ID = "Show menu"
DELETE_CONVE_ACCESSE_ID = "Delete conversation"
DELETE_BUTTON_TO_CONFIRM_ACCESSE_ID = "Approve"
