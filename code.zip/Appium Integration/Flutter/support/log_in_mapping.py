
FIRST_LOG_IN_BUTTON_ID = "Log in" #"com.tumblr:id/login_button"
LOG_IN_WITH_EMAIL_ID = "Log in with Email"
INPUT_EMAIL_XPATH = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]"
ERROR_MESSAGE_FOR_EMAIL_ACC_ID = "unvalid email"
ERROR_MESSAGE_FOR_PASSWORD_ACC_ID = "Please enter some text"
LOGIN_BUTTON_XPATH = "//android.widget.Button[@content-desc=\"Login\"]"
SCROLL_VIEW_XPATH = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.ScrollView/android.widget.EditText[2]"

########################
INPUT_PASSWORD_XPATH ="	/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]"
EMAIL_XPATH_AFTER_ERROR = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.ScrollView/android.widget.EditText[1]"
EMPTY_EMAIL_EROR_MSG_ACC_ID = "Please enter some text"
WRONG_EMAIL_OR_PASS_ACC_ID = "wrong Email or password please try again"