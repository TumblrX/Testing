class POST_VARIABLES():
    ###############LOGIN #################################
    LOGIN_BUTTON = "com.example.android.tumblrx2:id/btn_login"
    LOGIN_WITH_EMAIL_BUTTON = "com.example.android.tumblrx2:id/btn_signup_email"
    EMAIL_TEXT_ID = "com.example.android.tumblrx2:id/et_email"
    PASSWORD_TEXT_ID = "com.example.android.tumblrx2:id/et_password"
    SECOND_BUTTON_ID = "com.example.android.tumblrx2:id/btn_login"
    ############## ADD POSTS ###################
    ADD_POST_BUTTON="com.example.android.tumblrx2:id/button_addPost"
    POST_TEXT_XPATH = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.ListView/android.widget.EditText"
    POST_BUTTON_ID = "com.example.android.tumblrx2:id/post_button_text"
    HOME_BUTTON="//android.widget.FrameLayout[@content-desc=\"Home\"]/android.widget.ImageView"
    CHECK_CREATED_POST = "com.example.android.tumblrx2:id/post_text"