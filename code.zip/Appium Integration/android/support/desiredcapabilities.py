desired_cap = {
  "platformName": "Android",
  "appium:platformVersion": "8.0.0",
  "appium:deviceName": "HUAWEI GR3 2017",
  "appium:automationName": "Appium",
  "appium:udid": "PSE7N17802001262",
  "appium:appPackage": "com.example.tumblrx",
  "appium:appActivity": "com.example.tumblrx.MainActivity"
}
desiredcap = {
  "platformName": "Android",
  "appium:platformVersion": "10.0",
  "appium:deviceName": "Nada",
  "appium:automationName": "Appium",
  "appium:appPackage": "com.example.android.tumblrx2",
  "appium:appActivity": "com.example.android.tumblrx2.intro.IntroActivity"
}